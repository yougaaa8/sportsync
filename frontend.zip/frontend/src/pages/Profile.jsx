import { useEffect, useState } from "react"
import Navbar from "../components/Navbar.jsx"
import Footer from "../components/Footer.jsx"
import BlankProfilePicture from "../assets/blank-user-profile.jpg"
import "../stylesheets/profile.css"

export default function Profile() {
    const [username, setUsername] = useState("");

    useEffect(() => {
        const stored = localStorage.getItem("username");
        if (stored) setUsername(stored);
    }, []);

    return (
        <>
            <Navbar />
            <img className="profile-picture" src={BlankProfilePicture} />
            <h1>{username || "Guest"}</h1>
            <p>Email: </p>
            <p>Events Registered: </p>
            <p>Booked Facilities: </p>
            <p>CCA Attendance: </p>
            <Footer />
        </>
    )
}