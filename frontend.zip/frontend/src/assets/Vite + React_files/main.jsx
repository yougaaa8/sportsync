
<!DOCTYPE html>
<html>
<head>
    <title>Connecting to the forwarded port...</title>
    <meta charset="UTF-8" />
</head>
<body style="text-align: center;">
    <div>

        <p>Connecting to the forwarded port...</p>

        <form action="https://6k30kdg3-5173.asse.devtunnels.ms/auth/postback/github?rd=%2Fsrc%2Fmain.jsx%3Ft%3D1748823221840&amp;tunnel=1" method="POST" id="tokenForm">
            <input type="hidden" name="aadToken" value="" />
            <input type="hidden" name="gitHubToken" value="ghu_WBghuHCY9rYkn2WL0QAlW48swxWs4p38PsO2" />
        </form>

        <script>
            const formElement = document.getElementById("tokenForm");
            formElement.submit();
        </script>

    </div>
</body>
</html>
